/* doesn't work with source level 1.8:
module com.mycompany.ingegneria_software {
    requires javafx.controls;
    exports com.mycompany.ingegneria_software;
}
*/
